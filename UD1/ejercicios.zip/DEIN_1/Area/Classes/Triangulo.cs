﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Area
{
    class Triangulo
    {
        public static double CalcularArea(double b, double a)
        {
            return b * a / 2;
        }
    }
}
