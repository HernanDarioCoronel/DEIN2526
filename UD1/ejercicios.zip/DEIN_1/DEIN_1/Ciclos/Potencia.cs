﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEIN_1.Ciclos
{
    class Potencia
    {
        /**
         * 1. Hacer un programa que calcule la potencia, ya sea positiva o negativa, de cualquier exponente.
         * */
        public static void Calcular()
        {

        }
    }
}
